package com.zee.zee5app;

import java.math.BigDecimal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.zee.zee5app.dto.Register;
import com.zee.zee5app.service.UserService;

@SpringBootApplication
public class Zee5appspringbootApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext applicationContext =
				SpringApplication.run(Zee5appspringbootApplication.class, args);
		
		UserService userService = applicationContext.getBean(UserService.class);
		Register register = new Register("asz0000", "Arpit", "Shreshth", "aszee@gmail.com", "aszee123", null);
		register.setContactNumber(new BigDecimal("7903085868"));
		System.out.println(userService.addUser(register));
		
		applicationContext.close();
	}

}
