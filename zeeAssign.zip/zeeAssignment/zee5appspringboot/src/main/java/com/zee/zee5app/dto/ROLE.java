package com.zee.zee5app.dto;

public enum ROLE {
	
	ROLE_USER,
	ROLE_ADMIN

}
