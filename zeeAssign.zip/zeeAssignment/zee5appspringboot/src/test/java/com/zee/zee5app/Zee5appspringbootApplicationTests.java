package com.zee.zee5app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Zee5appspringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
