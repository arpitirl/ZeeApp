package com.zee.zee5_app.dto;

public enum ROLE {
	
	ROLE_USER,
	ROLE_ADMIN

}
